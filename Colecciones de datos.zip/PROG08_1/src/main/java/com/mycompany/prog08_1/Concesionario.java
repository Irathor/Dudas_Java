package com.mycompany.prog08_1;
import java.util.Collections;
import java.util.LinkedList;

/**
 *
 * @author Irathor
 */
public class Concesionario extends LinkedList<Vehiculo>{

      
    /**
     * 
     * @param matricula de entrada para la búsqueda.
     * @return posición del vehículo dentro del array.
     */
    public int posicionVehiculo(String matricula){
        
        for (Vehiculo vehiculo: this)
        {
            if (matricula.equals(vehiculo.getMatricula()))
            {
                return this.indexOf(vehiculo);
            }
        }
        return -1;
    }
        
    /**
     * 
     * @param matricula de entrada para la búsqueda de los datos.
     * @return String de salida con los datos pedidos.
     */
    public String buscaVehiculo(String matricula){
        
        int posicion=this.posicionVehiculo(matricula);
        
        if (posicion>=0)
        {
            Vehiculo coche = this.get(posicion);
            return "Marca: " + coche.getMarca()
                + "\nMatricula: " + coche.getMatricula() + "\nPrecio: " + coche.getPrecio();
        }
        return "No existe vehículo con la matrícula introducida";
    }
    
    /**
     * 
     * @param vehiculo
     * @throws Exception 
     */
    public void insertarVehiculo(Vehiculo vehiculo) throws Exception{
        
        int esta=Collections.binarySearch(this, vehiculo);
        
        if (esta>=0){
            
            throw new Exception("El vehículo ya ha sido introducido anteriormente.");
        }
        this.add(vehiculo);
        Collections.sort(this);
    }
    
    /**
     * Método que devuelve una lista con todos los datos pertenecientes al vehículo.
     * @return 
     */
    public String listaVehiculos(){
        
        String lista="";
        
        for (Vehiculo v: this){
            lista=lista + v.getMatricula() + "\n" + v.getMarca()
                    + "\n" + v.getPrecio() + " €\n" + v.getNumKm() + " Km";
        }
        return lista;
        
    }    
    
     /**
      * Modifico los métodos con el nuevo código. Queda mucho más reducido.
      * @return 
      */
    public int numVehiculos(){
        
        return this.size();
    }

}