package com.mycompany.prog08_1;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *
 * @author Irathor
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        
    int seccion;
    Scanner sc=new Scanner(System.in);
    Vehiculo vehiculo=null;
    Concesionario concesionario=new Concesionario();
    
    do
    {
        System.out.println("1. Nuevo Vehículo");
        System.out.println("2. Listar Vehículos");
        System.out.println("3. Buscar Vehículo");
        System.out.println("4. Modificar kms Vehículo");
        System.out.println("5. Eliminar Vehículo");
        System.out.println("6. Salir");
        
        seccion=sc.nextInt();
        sc.nextLine(); //necesario siempre que se ponga un nextInt.
        
        if(concesionario.numVehiculos()==0 &&(seccion<1 && seccion>5)){
            System.out.println("No hay ningún vehículo almacenado.");
        }
        else{
            switch (seccion){
                case 1:
                    vehiculo=crearVehiculo(sc);
                    concesionario.insertarVehiculo(vehiculo);
                    break;
                case 2:
                    String lista=concesionario.listaVehiculos();
                    System.out.println(lista);
                    break;
                case 3:
                    System.out.println("Matrícula del vehículo a encontrar: ");
                    String matricula = sc.nextLine();
                    System.out.println(concesionario.buscaVehiculo(matricula));
                    break;
                case 4:
                    System.out.println("Matricula del Vehículo al que actualizar sus Kms: ");
                    matricula = sc.nextLine();
                    int posicion = concesionario.posicionVehiculo(matricula);
                    if (posicion >= 0)
                    {
                        Vehiculo v = concesionario.get(posicion);
                        System.out.println("Los km del vehículo son " + v.getNumKm() 
                                            + ". Introduzca el nuevo valor:");
                        int nuevoKms = sc.nextInt();
                        sc.nextLine();
                        v.setNumKm(nuevoKms);
                        System.out.println("Los km actualizados del vehículo son " + v.getNumKm());
                    }
                    else
                    {
                        System.out.println("La matrícula introducida no existe");
                    }
                    break;
                case 5:
                    System.out.println("Introduzca la matrícula del vehículo a eliminar");
                    matricula = sc.nextLine();
                    posicion = concesionario.posicionVehiculo(matricula);
                    if (posicion >= 0)
                    {
                        concesionario.remove(posicion);
                        System.out.println("El vehículo ha sido eliminado");
                    }
                    else
                    {
                        System.out.println("La matrícula introducida no existe");
                    }
                    break;
                case 6:
                    System.out.println("Programa finalizado");
                    break;
                default:
                    System.out.println("Entrada inválida, vuelve a intentarlo.");
                    break;
            }
        }
        
    }
    while(seccion!=6);
    }
    
    private static Vehiculo crearVehiculo(Scanner sc){
        
        String marca;
        String matricula=null;
        String DNI=null;
        String nombre=null;
        String apellidos=null;
        int precio, km;
        
        System.out.println("Marca: ");
        marca=sc.nextLine();
        
        do
        {
            try{
                System.out.println("Matricula: ");
                String matriculaCompro=sc.nextLine();
                matricula=comprobarMatricula(matriculaCompro);
            }catch(Exception e){
                System.out.println(e.getMessage());
            }
            
        }
        while(matricula==null);
        
        System.out.println("Precio de compra: ");
        precio=sc.nextInt();
        sc.nextLine();
        
        do
        {
            try{
                System.out.println("DNI: ");
                String DNICompro=sc.nextLine();
                DNI=comprobarDNI(DNICompro);
            }catch(Exception e){
                System.out.println(e.getMessage());
            }
        }
        while(DNI==null);
        
        do
        {
            try{
                System.out.println("Nombre del propietario: ");
                String nombreCompro=sc.nextLine();
                nombre=comprobarNombre(nombreCompro);
            }catch(Exception e){
                System.out.println(e.getMessage());
            }
        }
        while(nombre==null);
        
        do
        {
            try{
                System.out.println("Apellidos del propietario: ");
                String apellidosCompro=sc.nextLine();
                apellidos=comprobarApellidos(apellidosCompro);
            }catch(Exception e){
                System.out.println(e.getMessage());
            }
        }
        while(apellidos==null);
        
        System.out.println("Km del vehículo: ");
        km=sc.nextInt();
        sc.nextLine();
        
        return new Vehiculo (marca, matricula, precio, DNI, nombre, apellidos, km);
    }
    
    /**
     * Método que compara los datos introducidos con un patrón creado.
     * @param matricula de entrada para comprobarla con un patrón
     * @return
     * @throws Exception.
     */
    private static String comprobarMatricula(String matricula) throws Exception{
        
        Pattern p=Pattern.compile("([0-9]{4})([A-Z]{3})");
        Matcher m=p.matcher(matricula);
        
        if(m.matches()){
            return matricula;
        }
        else{
            throw new Exception("No es una matrícula válida: (0000LLL)");
        }
    }
    
    /**
     * Método para comparar los datos de entrada del usuario con un patrón creado.
     * @param DNI de entrada para comprobarlo con un patrón.
     * @return
     * @throws Exception 
     */
    private static String comprobarDNI(String DNI) throws Exception{
        
        Pattern p=Pattern.compile("([0-9]{8})([A-Z])");
        Matcher m=p.matcher(DNI);
        
        if(m.matches()){
            return DNI;
        }
        else{
            throw new Exception ("No en un DNI válido: (00000000L)");
        }
    }
    
    /**
     * Método para comparar los datos de entrada con un patrón creado.
     * @param nombre de entrada para compararlo con el patrón.
     * @return
     * @throws Exception 
     */
    private static String comprobarNombre(String nombre) throws Exception{
        
        Pattern p=Pattern.compile("^[A-Za-z]{1,40}+$");
        Matcher m=p.matcher(nombre);
        
        if(m.matches()){
            return nombre;
        }
        else{
            throw new Exception("No es un nombre válido.");
        }
    }
    
    private static String comprobarApellidos(String apellidos) throws Exception{
        
        Pattern p=Pattern.compile("(^[A-Za-z]{1,20})(\\s)([A-Za-z]{1,20})");
        Matcher m=p.matcher(apellidos);
        
        if(m.matches()){
            return apellidos;
        }
        else{
            throw new Exception("Por favor, introduzca los dos apellidos.");
        }
        
    }
    
}