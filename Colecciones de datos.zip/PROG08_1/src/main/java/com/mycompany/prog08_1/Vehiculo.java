package com.mycompany.prog08_1;
/**
 *
 * @author Irathor
 */
/**
 * implemento el interfaz Comparable para usar el método compareTO
 * ahora podemos llamar al método sort para ordenar listas.
 */
public class Vehiculo implements Comparable<Vehiculo>{
    
    //atributos
    private String marca, DNI, nombre, apellidos;
    private int precio, numKm;
    public String matricula;
    
    //constructor
    Vehiculo (String mar, String matri, int prec, String Doc, String nom,
            String ape, int km){
        
        this.marca=mar;
        this.matricula=matri;
        this.precio=prec;
        this.DNI=Doc;
        this.nombre=nom;
        this.apellidos=ape;
        this.numKm=km;
    }
    
    //añado los getter y los setter de los atributos y los documento con javadoc.
    /**
     * 
     * @return marca.
     */
    public String getMarca(){
        return marca;
    }
    
    /**
     * 
     * @param mar modifica la marca.
     */
    public void setMarca(String mar){
        this.marca=mar;
    }
    
    /**
     * 
     * @return matricula.
     */
    public String getMatricula(){
        return matricula;
    }
    
    /**
     * 
     * @param matri modifica matricula.
     */
    public void setMatricula(String matri){
        this.matricula=matri;
    }
    
    /**
     * 
     * @return precio.
     */
    public int getPrecio(){
        return precio;
    }
    
    /**
     * 
     * @param prec modifica precio.
     */
    public void setPrecio(int prec){
        this.precio=prec;
    }
    
    /**
     * 
     * @return DNI.
     */
    public String getDNI(){
        return DNI;
    }
    
    /**
     * 
     * @param Doc modifica DNI.
     */
    public void setDNI(String Doc){
        this.DNI=Doc;
    }
    
    /**
     * 
     * @return nombre
     */
    public String getNombre(){
        return nombre;
    }
    
    /**
     * 
     * @param nom modifica nombre.
     */
    public void setNombre(String nom){
        this.nombre=nom;
    }
    
    /**
     * 
     * @return apellidos
     */
    public String getApellidos(){
        return apellidos;
    }
    
    /**
     * 
     * @param ape modifica apellidos.
     */
    public void setApellidos(String ape){
        this.apellidos=ape;
    }
    
    /**
     * 
     * @return numKm.
     */
    public int getNumKm(){
        return numKm;
    }
    
    /**
     * 
     * @param km modifica numKm.
     */
    public void setNumKm(int km){
        this.numKm=km;
    }

    @Override
    public int compareTo(Vehiculo vehiculo) {
        return this.matricula.compareTo(vehiculo.matricula); 
    }
        
}