package PROG05_Ejerc1;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import PROG05_Ejerc1_util.Validacion;
/**
 *
 * @author Irathor
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int seccion;
        //creo el objeto vehiculo y lo inicializo en null para asegurarme
        //de que el programa detecta que no hay ningún vehículo iniciado.
        Vehiculo vehiculo = null;
        
        do
        {
            //Creo el menú a mostrar.
            System.out.println("1. Nuevo Vehículo");
            System.out.println("2. Ver Matrícula");
            System.out.println("3. Ver Número de Kilómetros");
            System.out.println("4. Actualizar Kilómetros");
            System.out.println("5. Ver años de antigüedad");
            System.out.println("6. Mostrar propietario");
            System.out.println("7. Mostrar descripción");
            System.out.println("8. Mostrar precio");
            System.out.println("9. Salir");
            
            seccion=sc.nextInt();
            //es necesario meter un nextLine tras un nextInt para evitar que salte de línea.
            sc.nextLine();

            //hago la comprobación de que haya al menos un vehículo para mostrar algo.
            if (vehiculo == null && (seccion !=1)){
                System.out.println("No hay ningún vehículo almacenado, por favor introduce uno");
            }else{
            
                switch (seccion){
                    case 1:
                        try{
                            vehiculo=insertarCoche(sc);
                        }catch(Exception e){
                            System.out.println(e.getMessage());
                        }
                        break;
                    case 2:
                        System.out.println("Matricula: "+ vehiculo.getMatricula());
                        break;
                    case 3:
                        System.out.println("Número de Kilómetros recorridos: "+ vehiculo.getKm());
                        break;
                    case 4:
                        System.out.println("Nuevo kilometraje: ");
                        int numKm=sc.nextInt();
                        sc.nextLine();
                        try{
                            actualizarKm(numKm,vehiculo);
                        }catch(Exception e){
                            System.out.println(e.getMessage());
                        }
                        break;
                    case 5:
                        System.out.println("La antigüedad es de "+ vehiculo.getMatricula() + " años");
                        break;
                    case 6:
                        System.out.println("Nombre del propietario: "+ vehiculo.getNombre());
                        break;
                    case 7:
                        System.out.println(vehiculo.getDescripcion());
                        break;
                    case 8:
                        System.out.println("Precio: "+ vehiculo.getMatricula() + " €");
                        break;
                    case 9:
                        System.out.println("Programa terminado");
                    default:
                        System.out.println("No has introducido un valor válido");
                        break;
                
                        }
            
            }

        }
        while(seccion!=9);
        
    }
    
    private static Vehiculo insertarCoche(Scanner sc) throws Exception{
        
        String marca, matricula, descripcion, nombre, DNI, DNICompro;
        int precio, numKmCompro;
        LocalDate fechaMatriculacion;
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        
        System.out.println("Marca: ");
        marca=sc.nextLine();
        
        System.out.println("Matrícula: ");
        matricula=sc.nextLine();
        
        System.out.println("Km del cuentakilómetros: ");
        //necesita de una comprobación.
        numKmCompro=sc.nextInt();
        sc.nextLine();
        int numKm=setKm(numKmCompro);
        
        System.out.println("Fecha de matriculación del vehículo: Introduzca AAAA/MM/dd");
        String fecha=sc.nextLine();
        //variable para la comprobación.
        LocalDate fechacompro=LocalDate.parse(fecha, dateTimeFormatter);
        //no tengo el método todadía, pero así me sirve para hacer comprobaciones.
        fechaMatriculacion=setFechaMatriculacion(fechacompro);
        
        System.out.println("Añada una breve descripción del vehículo: ");
        descripcion=sc.nextLine();
        
        System.out.println("Precio de compra del vehículo: ");
        precio=sc.nextInt();
        sc.nextLine();
        
        System.out.println("Nombre del propietario del vehículo: ");
        nombre=sc.nextLine();
        
        System.out.println("DNI del propietario del vehículo: ");
        //necesito de una variable de comprobación para pasárselo al método validar.
        DNICompro=sc.nextLine();
        DNI=setDNI(DNICompro);
        
        return new Vehiculo(marca, matricula, numKm, fechaMatriculacion, descripcion, precio, nombre, DNI);
    }
    
    private static int setKm(int numKm) throws Exception{
        
        if(Validacion.kmValidos(numKm)){
            return numKm;
        }
        else{
            throw new Exception("No puedes introducir un valor negativo");
        }
        
    }
    
    private static LocalDate setFechaMatriculacion(LocalDate fecha) throws Exception{
        
        LocalDate hoy=LocalDate.now();
        int comprobacion=fecha.compareTo(hoy);
        
        if(comprobacion<0){
            return fecha;
        }
        else{
            throw new Exception("El vehículo ha de estar matriculado antes de hoy");
        }
    }
    
    private static int actualizarKm(int nuevoKm, Vehiculo vehiculo) throws Exception{
        
        if(nuevoKm>vehiculo.getKm()){
            return nuevoKm;
        }
        else{
            throw new Exception ("No se puede disminuir el kilometraje del vehículo");
        }
        
    }
    
    private static String setDNI(String DNICompro) throws Exception{
        
        if(Validacion.validarNIF(DNICompro)){
            return DNICompro;
        }
        else{
            throw new Exception("DNI inválido");
        }
        
    }
    
}
