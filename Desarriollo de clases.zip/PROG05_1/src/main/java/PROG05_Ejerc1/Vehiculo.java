package PROG05_Ejerc1;
import java.time.LocalDate;
import java.time.Duration;
/**
 *
 * @author Irathor
 */
public class Vehiculo {
    
    //atributos
    private String marca;
    private String matricula;
    private int numKm;
    private LocalDate fechaMatriculacion;
    private String descripcion;
    private int precio;
    private String nombre;
    private String DNI;
    
    //constructor
    Vehiculo(String mar, String matri, int km, LocalDate fechMatri, String descri,
            int prec, String cliente, String docind){
            
        this.marca = mar;
        this.matricula=matri;
        this.numKm = km;
        this.fechaMatriculacion=fechMatri;
        this.descripcion=descri;
        this.precio=prec;
        this.nombre=cliente;
        this.DNI=docind;
            
    }
    
    //getters y setters
    public String getMatricula(){
        return matricula;
    }
    
    public int getKm(){
        return numKm;
    }
    //para los km es necesario un set porque es posible actualizarlos.
    public void setKm(int km){
        numKm=km;
    }
    //para ver la antigüedad tengo que comparar la fecha de matriculación
    //con el día de hoy. Usaré la función toDays, por lo que he de convertirlo a años.
    //necesita la biblioteca Duration.
    public int getAnios(){
        Duration duration = Duration.between(fechaMatriculacion.atStartOfDay(), 
                                            LocalDate.now().atStartOfDay());
        float dias=duration.toDays();
        //casteo para devolver un int.
        return (int)(dias/365);
    }
    
    public String getNombre(){
        return nombre;
    }
    //la descripción incluye la matrícula y el número de kilómetros a parte de la propia
    //descripcion.
    public String getDescripcion(){
        return "matricula: " + matricula + " KM " + numKm + "\n" +descripcion;
    }
    
    public int getPrecio(){
        return precio;
    }
    
    public String getDNI(){
        return DNI;
    }
    
}
