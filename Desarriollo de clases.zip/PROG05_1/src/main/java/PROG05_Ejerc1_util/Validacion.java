package PROG05_Ejerc1_util;

/**
 *
 * @author Irathor
 */
public class Validacion {
    public int numDNI;
    public static final String LETRAS_DNI= "TRWAGMYFPDXBNJZSQVHLCKE";

    public static char calcularLetraNIF(int dni){
    char letra;
    letra = LETRAS_DNI.charAt(dni % 23);
    return letra;
    }
    
    public static char extraerLetraNIF (String nif){
    char letra = nif.charAt(nif.length()-1);
    return letra;
    }

    public static int extraerNumeroNIF (String nif){
    int numero = Integer.parseInt(nif.substring(0, nif.length()-1));
    return numero;
    }
    
    public static boolean validarNIF (String nif){
    boolean valido = true;
    char letra_calculada;
    int dni_leido;
    char letra_leida;
    
    
    if (nif == null) {
        valido = false;
    }
    
    else if (nif.length()<8 || nif.length()>9) {
        valido= false;
    }
    else {
        letra_leida= Validacion.extraerLetraNIF(nif);
        dni_leido= Validacion.extraerNumeroNIF(nif);
        letra_calculada= Validacion.calcularLetraNIF(dni_leido);
        
        if (letra_leida == letra_calculada){
           valido = true;   
           }
        else{
           valido = false;
        }
     }
    return valido;
    }
        
    public static boolean kmValidos(int numKm){
    boolean valido;
    if (numKm <0){
        valido = false;
    }
    else {
        valido = true;
    }
    return valido;
    }
}
