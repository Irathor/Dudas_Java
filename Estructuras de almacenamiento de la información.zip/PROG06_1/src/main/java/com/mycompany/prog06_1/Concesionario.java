package com.mycompany.prog06_1;
import java.util.Arrays;

/**
 *
 * @author Irathor
 */
public class Concesionario {
    
    //creo el Array de vehículos.
    Vehiculo[] vehiculo;

    //creo el constructor.
    Concesionario(){
        this.vehiculo=new Vehiculo[50];
    }
    
    /**
     * 
     * @param matricula de entrada para la búsqueda.
     * @return posición del vehículo dentro del array.
     */
    public int posicionVehiculoArray(String matricula){
        
        int posicion=-1;
        for (int i=0; i<50; i++){
            if(this.vehiculo[i] !=null && matricula.equals(this.vehiculo[i].matricula)){
                posicion=i;
                break;
            }
            
        }
        return posicion;
    }
        
    /**
     * 
     * @param matricula de entrada para la búsqueda de los datos.
     * @return String de salida con los datos pedidos.
     */
    public String buscaVehiculo(String matricula){
        
        int posicion=this.posicionVehiculoArray(matricula);
        
        if(posicion==-1){
            String mensaje="No existe el vehículo introducido";
            return mensaje;
        }
        else{
            String mensaje="Marca: " + this.vehiculo[posicion].getMatricula() + "Precio: " 
                    + this.vehiculo[posicion].getPrecio();
            return mensaje;
        }
    }
    
    /**
     * 
     * @return hueco que es el primer hueco libre del array.
     */
    public int primerHuecoLibre(){
        //lo inicio en -1 para no darle un valor válido del array y que me pueda dar problemas.
        int hueco=-1;
        for(int i=0;i<50;i++){
            if(this.vehiculo[i]==null){
                hueco=i;
                break;
            }
        }
        return hueco;
    }
      
    /**
     * método para meter vehículos en el array.
     * @param vehiculo
     * @return valor que es lo que pide el ejercicio.
     */
    public int insertarVehiculo(Vehiculo vehiculo){
        
        //valor devuelto
        int valor=0;
        //posición del primer hueco libre
        int posicion=primerHuecoLibre();
        //pocición del vehículo en el array en caso de encontrarlo.
        int matriculaPosicion=this.posicionVehiculoArray(vehiculo.getMatricula());
        
        if(matriculaPosicion<50 && matriculaPosicion>=0){
            System.out.println("El vehículo ya se encuentra en el almacén");
            valor=-2;
            return valor;
        }
        else if (posicion == -1){
            System.out.println("El concesionario está vacío");
        }
        else{
            this.vehiculo[posicion]=vehiculo;
            valor=0;
        }
        
        return valor;
        
    }
    
    /**
     * Método que devuelve una lista con todos los datos pertenecientes al vehículo.
     */
    public void listaVehiculos()
    {
        for (int i=0; i<50; i++)
        {
            if (this.vehiculo[i]!= null)
            {
            System.out.println("Vehículo " + (i+1) + "\nMatrícula: " + this.vehiculo[i].getMatricula() 
                    + "\nMarca: " + this.vehiculo[i].getMarca()
                    + "\nPrecio: " + this.vehiculo[i].getPrecio() + " €\nKilometraje: " 
                    + this.vehiculo[i].getNumKm() + " Km\n");
           }
        }
        
    }    
    
    /**
     * 
     * @param matricula la recibe para seleccionar el vehículo del array.
     * @param numKms para modificar los Km del vehículo.
     */
    public void actualizaKms(String matricula, int numKms){
        
        int posicion = this.posicionVehiculoArray(matricula);
        this.vehiculo[posicion].setNumKm(numKms);
    }
    
     /**
     * Método que no uso pero que creo que se pide en el ejercicio y que se almacena en un int.
     * @return TotalVehiculos total de vehículos almacenados
     */
    public int numVehiculos()
    {
        int totalVehiculos = 0;
        for (int i=0; i<50; i++)
        {
            if(this.vehiculo[i]!=null)
            {
                totalVehiculos++;
            }
        }
        return totalVehiculos;
    }

}
