package PacFechas;

/**
 * @author Irathor
 */
public class Fecha {
    
    //Creo las variables día y año y las inicializo en 0
    int dia;
    int anio;
    
    //Creo el enum
    public enum enumMes{
        ENERO, FEBRERO, MARZO, ABRIL, MAYO, JUNIO, JULIO, AGOSTO, SEPTIEMBRE, 
        OCTUBRE, NOVIEMBRE, DICIEMBRE;
    }
    //Creo su variable mes
    enumMes mes;
    //Creo el constructor que inicializa el mes y pone el resto de variables a 0
    Fecha (enumMes mes){
        this.mes = mes;
        dia=0;
        anio=0;
    }
    //Creo el constructor que 
    Fecha (int anio, enumMes mes, int dia){
        this.anio=anio;
        this.mes=mes;
        this.dia=dia;
    }
    
    //Creo los getter y los setter para dar valor a las variables de Fecha
    public int getAnio(){
        return anio;
    }
    
    public void setAnio(int anio){
        this.anio=anio;
    }
    
    public enumMes getMes(){
        return mes;
    }
    
    public void setMes(enumMes mes){
        this.mes=mes;
    }
    
    public int getDia(){
        return dia;
    }
    
    public void setDia(int dia){
        this.dia=dia;
    }
    //Creo el método booleano para saber si es verano.
    public void isSummer(){
        /*Al tener declarado el enum con chars tengo que registrar todos los
        meses que abarca verano. También recoger los días que pueden ser de
        los determinados meses en que cambia*/
        boolean esVerano= (mes==enumMes.JUNIO && dia>=21) || (mes==enumMes.JULIO)
                || (mes==enumMes.AGOSTO) || (mes==enumMes.SEPTIEMBRE && dia<=22);
        
        //muestro por pantalla si es verano o no.
        if (esVerano==true){
            System.out.println("Es verano");
        }
        else{
            System.out.println("No es verano");
        }
    }
    
    public String fechaLargo (){
        String string = (dia + " " + mes + " " + anio);
        return string;
    }
    
}
