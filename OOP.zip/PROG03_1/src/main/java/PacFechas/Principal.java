/*
Cambio el nombre del package al
crear el proyecto. 
*/
package PacFechas;
import PacFechas.Fecha.enumMes;

/**
 * @author Irathor
 */
public class Principal {
    /**
     * @param args the command line arguments
     * Aquí introduzco todo lo que se va a mostrar por pantalla.
     */
    public static void main(String[] args) {
        //Según el ejemplo 
        // Primer ejemplo
        System.out.println("Primera fecha, inicializada con el primer constructor");
        Fecha objFecha1 = new Fecha(enumMes.FEBRERO);
        objFecha1.setDia(20);
        objFecha1.setAnio(2000);
        System.out.println(objFecha1.fechaLargo());
        objFecha1.isSummer();
        
        //Segundo ejemplo
        System.out.println("Segunda fecha, inicializada con el segundo constructor");
        Fecha objFecha2 = new Fecha(15,enumMes.JULIO, 2015);
        System.out.println("La fecha 2 contiene el año " + objFecha2.getAnio());
        System.out.println(objFecha2.fechaLargo());
        objFecha2.isSummer();
    }
    
}
